AOS.init();


import { Tab, initMDB } from "mdb-ui-kit";

initMDB({ Tab });
